'''
Created on Oct 7, 2015

@author: Ankit Bhankharia atb5880
@author: Uday Wadhone uw1919
'''
import Node
import HFunctions
import sys
import copy
#from DiceMazePuzzle import startPosition, goalPosition

# key value pair of nodes generated
openList = {}
# key value pair of nodes visited
closedList = {}
# Actual puzzle
mazePuzzle = []
# start position [x,y]
startPos = []
# goal position [x,y]
goalPos = []
# number of nodes generated
noOfMoves = 1
# number of nodes visited
nodesVisited = 0
# Which heuristic function to call
heuristicFunc = 0
    
def solve(startPosition, goalPosition, maze, heuristic):
    global mazePuzzle
    global startPos
    global goalPos
    global heuristicFunc
    global openList
    global nodesVisited
    global noOfMoves
    goalFound = False
    openList.clear()
    closedList.clear()
    nodesVisited = 0
    noOfMoves = 0
    heuristicFunc = heuristic
    mazePuzzle = maze
    startPos = startPosition
    goalPos = goalPosition
    
    nodeKey = str(startPosition[0]) + "," + str(startPosition[1]) + "," + "1,2,3"
    # decides which heuristic function to call to calculate h value
    if(heuristicFunc == 1):
        gCost = HFunctions.euclidianDistance(startPosition, goalPosition)
    elif(heuristicFunc == 2):
        gCost = HFunctions.manhattanDistance(startPosition, goalPosition)
    elif(heuristicFunc == 3):
        gCost = HFunctions.distance3(startPosition, goalPosition, 1)
    hCost = 0
    # creates a starting node
    startNode = Node.Node(startPosition[0], startPosition[1], None, gCost, hCost,1,2,3)
    # Adds starting node to open list
    openList[nodeKey] = startNode
    
    while(len(openList) > 0):
        nodesVisited = nodesVisited + 1
        fcostTemp = sys.maxsize
        minNodePosition = None
        # finds the node with minimum f cost
        for key, value in openList.items():
            if(value.fCost < fcostTemp):
                fcostTemp = value.fCost
                minNodePosition = key
        currentNode = openList[minNodePosition]
        # Checks if goal is reached
        if(currentNode.X == goalPos[0] and currentNode.Y == goalPos[1] and currentNode.faceUp == 1):
            print("goal Found")
            display(currentNode)
            print("Number of nodes added to frontier queue: " + str(noOfMoves))
            print()
            print("Number of nodes visited: " + str(nodesVisited))
            goalFound = True
            break
        # removes value from open list
        openList.pop(minNodePosition)
        # and adds it to closed list
        closedList[minNodePosition] = currentNode
        # Adds the neighbors
        getNeighbors(minNodePosition)
    
    # If no goal found
    if(goalFound == False):
        print("No Solution")
        print("Number of nodes added to frontier queue: " + str(noOfMoves))
        print()
        print("Number of nodes visited: " + str(nodesVisited))
        
def getNeighbors(parentPosition):
    nodeParent = closedList[parentPosition]
    newPosition = parentPosition.split(',')
    xPosParent = int(newPosition[0])
    yPosParent = int(newPosition[1])
    upParent = int(newPosition[2])
    northParent = int(newPosition[3])
    rightParent = int(newPosition[4])
    childHCost = nodeParent.hCost + 1
    
    # Moving UP
    if(xPosParent - 1 >= 0):
        if(mazePuzzle[xPosParent - 1][yPosParent] != '*'):
            upChildUp = 7-northParent
            northChildUp = upParent
            rightChildUp = rightParent
            if(not upChildUp == 6):
                addChildNode(xPosParent - 1, yPosParent, upChildUp, northChildUp, rightChildUp, childHCost, nodeParent, upChildUp)

    #Moving down
    if(xPosParent + 1 < len(mazePuzzle)):
        if(mazePuzzle[xPosParent + 1][yPosParent] != '*'):
            upChildDown = northParent
            northChildDown = 7 - upParent
            rightChildDown = rightParent
            if(not upChildDown == 6):
                addChildNode(xPosParent + 1, yPosParent, upChildDown, northChildDown, rightChildDown, childHCost, nodeParent, upChildDown)
    
    #Moving left           
    if(yPosParent - 1 >= 0):
        if(mazePuzzle[xPosParent][yPosParent - 1] != '*'):
            upChildLeft = rightParent
            northChildLeft = northParent
            rightChildLeft = 7 - upParent
            if(not upChildLeft == 6):
                addChildNode(xPosParent, yPosParent - 1, upChildLeft, northChildLeft, rightChildLeft, childHCost, nodeParent, upChildLeft)
    
    #Moving right
    if(yPosParent + 1 < len(mazePuzzle[0])):
        if(mazePuzzle[xPosParent][yPosParent + 1] != '*'):
            upChildRight = 7 - rightParent
            northChildRight = northParent
            rightChildRight = upParent
            if(not upChildRight == 6):
                addChildNode(xPosParent, yPosParent + 1, upChildRight, northChildRight, rightChildRight, childHCost, nodeParent, upChildRight)

# Adds the child to the open list
def addChildNode(xPos, yPos, upChild, northChild, rightChild, childHCost,nodeParent, childFaceUP):
    global noOfMoves
    if(heuristicFunc == 1):
        childGCost = HFunctions.euclidianDistance([xPos, yPos], goalPos)
    elif(heuristicFunc == 2):
        childGCost = HFunctions.manhattanDistance([xPos, yPos], goalPos)
    elif(heuristicFunc == 3):
        childGCost = HFunctions.distance3([xPos, yPos], goalPos, childFaceUP)
    childKey = getKey(xPos, yPos, upChild, northChild, rightChild)
    childNode = Node.Node(xPos, yPos, nodeParent, childGCost, childHCost, upChild, northChild, rightChild)
    # Checks if node is already present in closed list
    if(not closedList.__contains__(childKey)):
        # checks if node is present in open list
        # If yes then compare the f value
        if(openList.__contains__(childKey)):
            getNode = openList[childKey]
            if(childNode.fCost < getNode.fCost):
                openList[childKey] = childNode
                noOfMoves = noOfMoves + 1
        else:
            openList[childKey] = childNode
            noOfMoves = noOfMoves + 1

# generates a key for a node which is used in open list and closed list
def getKey(xPos, yPos, up, north, right):
    return (str(xPos) + "," + str(yPos) + "," + str(up) + "," + str(north) + "," + str(right))

# Tracks back the path from goal to start
def findPath(node):
    path = []
    path.append(node)
    while (not (node.X == startPos[0] and node.Y == startPos[1] and node.faceUp == 1)):
        path.append(node.parent)
        node = node.parent
    return path

# Display function
def display(node):
    path = findPath(node)
    path.reverse()
    print("Path Cost: " + str(len(path)))
    print("----------------------------------------------------------------------------------")
    print()
    mazeTemp = copy.deepcopy(mazePuzzle)
    for k in range(len(path)):
        x = path[k].X
        y = path[k].Y
        faceUp = path[k].faceUp
        for i in range(len(mazeTemp)):
            for j in range(len(mazeTemp[i])):
                if(x == i and y == j):
                    mazeTemp[i][j] = faceUp
                print(str(mazeTemp[i][j]) + " ", end ='')
            print()
        print()
        

        print("Die Orientation for above step")
        print("Position: " + str(path[k].X) + ", " + str(path[k].Y))
        print("Facing: " + str(path[k].faceUp))
        print("North: " + str(path[k].faceNorth))
        print("East: " + str(path[k].faceRight))
        print()
        print()