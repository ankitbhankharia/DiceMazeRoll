'''
Created on Oct 7, 2015

@author: Ankit Bhankharia atb5880
@author: Uday Wadhone uw1919
'''

# It stores the state of every node
class Node:
    def __init__(self, x, y, parent, gcost, hcost, up, north, right):
        self.X = x # x value
        self.Y = y # y value
        self.parent = parent # stores parent node(helps in tracking the path)
        self.hCost = hcost # heuristic value
        self.gCost = gcost # g value
        self.fCost = self.gCost + self.hCost # f value
        self.faceUp = up # die face up
        self.faceRight = right # die face right
        self.faceNorth = north # die face north