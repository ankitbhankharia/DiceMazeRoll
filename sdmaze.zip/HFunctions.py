'''
Created on Oct 7, 2015

@author: Ankit Bhankharia atb5880
@author: Uday Wadhone uw1919
'''
import math

# Calculates heuristic value based on Euclidean distance
def euclidianDistance(current, goal):
    xCurrent = current[0]
    yCurrent = current[1]
    xGoal = goal[0]
    yGoal = goal[1]
    
    return math.sqrt(math.pow((xCurrent - xGoal), 2) + math.pow((yCurrent - yGoal),2))

# Calculates heuristic value based on Manhattan distance
def manhattanDistance(current, goal):
    xCurrent = current[0]
    yCurrent = current[1]
    xGoal = goal[0]
    yGoal = goal[1]
    
    return math.fabs(xCurrent - xGoal) + math.fabs(yCurrent - yGoal)

# Calculates heuristic value based on improved version of Manhattan distance
def distance3(current, goal, currentFaceUP):
    xCurrent = current[0]
    yCurrent = current[1]
    xGoal = goal[0]
    yGoal = goal[1]
    # calculates the Manhattan distance
    manDistance = manhattanDistance(current, goal)
    xDiff = math.fabs(xCurrent - xGoal)
    yDiff = math.fabs(yCurrent - yGoal)
    
    # If you have reached goal state but die face is not 1 then it will take
    # 4 more moves i.e. by again visiting its neighbors
    if xDiff == 0 and yDiff == 0 and not (currentFaceUP == 1):
        return 4
    
    # If its not a goal state and die face is 1 at current state, then it will take manhattan
    # distance + 4 moves because it needs 1 and 6 on the side so that it can directly roll in a line
    if xDiff > 0 and yDiff > 0 and currentFaceUP == 1:
        return manDistance + 4
    
    # returns Manhattan distance if above cases doesn't satisfy
    return manDistance