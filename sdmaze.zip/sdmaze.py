'''
sdmaze.py
Created on Oct 7, 2015

Implements A* algorithm to find the cost in a maze

@author: Ankit Bhankharia atb5880
@author: Uday Wadhone uw1919
'''
import re
import sys
import Solver

# Stores the starting position [x,y]
startPosition = []
# Stores the goal position [x,y]
goalPosition = []
# Stores the actual maze
maze = []

class sdmaze:
    
    def __init__(self, filename):
        global maze
        maze = self.takeInput(filename)
    
    #reads input from the file
    def takeInput(self, filename):
        rows = []
        file = open(filename)
        for line in file:
            newLine = re.sub(r'$\n','', line)      
            rows.append(list(newLine))
        
        file.close()
        
        self.maze = self.formMatrix(rows)
        return self.maze
    
    # Creates a maze as a 2D matrix
    def formMatrix(self, rows):
        numRow = len(rows)
        matrix = [[0 for x in range(len(rows[0]))] for x in range(numRow)]
        for i in range (numRow):
            for j in range (len(rows[i])):
                matrix[i][j] = rows[i][j]
                global startPosition
                global goalPosition
                if(rows[i][j] == 'S'):
                    startPosition.append(i)
                    startPosition.append(j)
                
                if(rows[i][j] == 'G'):
                    goalPosition.append(i)
                    goalPosition.append(j)
        
        return matrix


# Program starts here.
# Creates an object and sends the file
puzzle = sdmaze(sys.argv[1])
print("------------------------------------Heuristic Function - Euclidean----------------------------")
# Calls the solve method which solves the puzzle using Euclidean distance
Solver.solve(startPosition, goalPosition, maze, 1)
print(" ---------------------------------------Heuristic Function - Manhattan --------------------------------")
# Calls the solve method which solves the puzzle using Manhattan distance
Solver.solve(startPosition, goalPosition, maze, 2)
print(" ---------------------------------------Heuristic Function - Manhattan Modification --------------------------------")
# Calls the solve method which solves the puzzle using modified version of Manhattan distance
Solver.solve(startPosition, goalPosition, maze, 3)